/*
 * HuffmanTest.h
 *
 *  Created on: May 03, 2017
 *      Author: Tyler Pillay
 */

#ifndef HUFFMANTEST_H_
#define HUFFMANTEST_H_

#include "catch.hpp"
#include "HuffmanTree.h"
#include "HuffmanNode.h"

#endif /* HUFFMANTEST_H_ */
